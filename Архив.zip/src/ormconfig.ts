import { DataSourceOptions } from 'typeorm';
import { UserEntity } from './user/user.entity';

const ormconfig: DataSourceOptions = {
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: 'user',
  password: '123',
  database: 'test',
  //entities: [__dirname + '/**/*.entity.ts{.ts, .js}'],
  entities: [UserEntity],
  synchronize: true,
};

export default ormconfig;
