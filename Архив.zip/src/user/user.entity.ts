import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('users_table')
export class UserEntity {
  @PrimaryGeneratedColumn()
  id: string;

  @Column({ nullable: true })
  trelloId: string;

  /*   @Column()
  oauthToken: string;

  @Column()
  oauthTokenSecret: string; */

  @Column({ nullable: true })
  accessToken?: string;
}
